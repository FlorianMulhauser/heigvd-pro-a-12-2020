var express = require("express");
var app = express();app.listen(3000, () => {
 console.log("Server running on port 3000");
});

const chat_message = require('./data/chat/chat_message.json');
const user = require('./data/user/user.json');


const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://test_node_js:RuegysTcToF1nGr2@progroupa12-f3mld.gcp.mongodb.net/test?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  client.close();
});


app.get("/chat_message", (req, res, next) => {
  res.header("Content-Type",'application/json');
  res.send(getChatMessage(1,1,null));
});

app.get("/user", (req, res, next) => {
  res.header("Content-Type",'application/json');
  res.send(JSON.stringify(user));
});

function getChatMessage(user_id,course_id,token) {
	return JSON.stringify(chat_message.id);
}