// todo Implementer le chatkit ici 
const chatManager = new ChatManager({
  instanceLocator: 'v1:us1:95984d78-e43e-47d8-9605-0f4c53fde0ce',
  userId: 'userPRO1',
  tokenProvider: new TokenProvider({ url: 'https://us1.pusherplatform.io/services/chatkit_token_provider/v1/95984d78-e43e-47d8-9605-0f4c53fde0ce/token' })
})
